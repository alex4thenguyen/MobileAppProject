package com.example.loginscreen;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    private EditText editTextName, editTextPhoneNumber, editTextNewUsername, editTextNewPassword, editTextConfirmPassword;
    private Button buttonRegister, buttonBack;

    private static final String PREFS_NAME = "MyPrefsFile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editTextName = findViewById(R.id.editTextName);
        editTextPhoneNumber = findViewById(R.id.editTextPhoneNumber);
        editTextNewUsername = findViewById(R.id.editTextNewUsername);
        editTextNewPassword = findViewById(R.id.editTextNewPassword);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        buttonRegister = findViewById(R.id.buttonRegister);
        buttonBack = findViewById(R.id.buttonBack);

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextName.getText().toString();
                String phoneNumber = editTextPhoneNumber.getText().toString();
                String username = editTextNewUsername.getText().toString();
                String password = editTextNewPassword.getText().toString();
                String confirmPassword = editTextConfirmPassword.getText().toString();

                if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phoneNumber) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(confirmPassword)) {
                    Toast.makeText(RegisterActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else if (!isValidPhoneNumber(phoneNumber)) {
                    Toast.makeText(RegisterActivity.this, "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
                } else if (!password.equals(confirmPassword)) {
                    Toast.makeText(RegisterActivity.this, "Password do not match. Please try again", Toast.LENGTH_SHORT).show();
                } else if (isFieldAlreadyRegistered(username, phoneNumber, name)) {
                    Toast.makeText(RegisterActivity.this, "The name, phone number, and username already exists. Please use another input", Toast.LENGTH_SHORT).show();
                } else if (isNameRegistered(name)) {
                    Toast.makeText(RegisterActivity.this, "The name already exists. Please use another name", Toast.LENGTH_SHORT).show();
                } else if (isPhoneNumberRegistered(phoneNumber)) {
                    Toast.makeText(RegisterActivity.this, "The phone number already exists. Please use another phone number", Toast.LENGTH_SHORT).show();
                } else if (isUsernameRegistered(username)) {
                    Toast.makeText(RegisterActivity.this, "The username already exists. Please use another username", Toast.LENGTH_SHORT).show();
                } else {
                    saveRegistrationInfo(username, password, name, phoneNumber);

                    Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean isFieldAlreadyRegistered(String username, String phoneNumber, String name) {
        Set<String> registeredValues = getRegisteredValues("userRegistration");

        String combination = username + "_" + phoneNumber + "_" + name;
        return registeredValues.contains(combination);
    }
    private boolean isNameRegistered(String name) {
        Set<String> registeredNames = getRegisteredValues("nameRegistration");

        return registeredNames.contains(name);
    }

    private boolean isPhoneNumberRegistered(String phoneNumber) {
        Set<String> registeredPhoneNumbers = getRegisteredValues("phoneNumberRegistration");

        return registeredPhoneNumbers.contains(phoneNumber);
    }

    private boolean isUsernameRegistered(String username) {
        Set<String> registeredUsernames = getRegisteredValues("usernameRegistration");

        return registeredUsernames.contains(username);
    }

    private void saveRegistrationInfo(String username, String password, String name, String phoneNumber) {
        saveValue("password_" + username, password);

        saveValue("name_" + username, name);
        saveValue("phoneNumber_" + username, phoneNumber);

        Set<String> updatedRegisteredValues = getRegisteredValues("userRegistration");
        String combination = username + "_" + phoneNumber + "_" + name;
        updatedRegisteredValues.add(combination);
        saveRegisteredValues("userRegistration", updatedRegisteredValues);

        Set<String> nameRegisteredValues = getRegisteredValues("nameRegistration");
        nameRegisteredValues.add(name);
        saveRegisteredValues("nameRegistration", nameRegisteredValues);

        Set<String> phoneNumberRegisteredValues = getRegisteredValues("phoneNumberRegistration");
        phoneNumberRegisteredValues.add(phoneNumber);
        saveRegisteredValues("phoneNumberRegistration", phoneNumberRegisteredValues);

        Set<String> usernameRegisteredValues = getRegisteredValues("usernameRegistration");
        usernameRegisteredValues.add(username);
        saveRegisteredValues("usernameRegistration", usernameRegisteredValues);
    }

    private void saveRegisteredValues(String field, Set<String> values) {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        editor.putStringSet(field, values);
        editor.apply();
    }

    private void saveValue(String key, String value) {
        SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
        editor.putString(key, value);
        editor.apply();
    }

    private Map<String, String> getUserMap() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String userMapJson = prefs.getString("userMap", "{}");

        return new Gson().fromJson(userMapJson, new TypeToken<HashMap<String, String>>() {}.getType());
    }

    private Set<String> getRegisteredValues(String field) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getStringSet(field, new HashSet<>());
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        String phonePattern = "^[0-9]{10}$";
        return Pattern.matches(phonePattern, phoneNumber);
    }
}
