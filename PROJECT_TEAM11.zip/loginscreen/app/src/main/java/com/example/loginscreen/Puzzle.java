package com.example.loginscreen;

import java.util.ArrayList;
import java.util.List;

public class Puzzle {
    private List<String> words2Guess;
    private List<String> originalWords2Guess; // Stores the original list of words
    private List<String> guessedWords = new ArrayList<>();
    private List<String> correctGuessedWords = new ArrayList<>();
    private List<Character> uniqueLetters = new ArrayList<>();
    private List<String> hints;
    private boolean isSolved = false;
    private int score = 0;
    private int deduction = 0; // Added field
    private boolean isCheating = false;

    public Puzzle(ArrayList<String> words2Guess, ArrayList<String> hints) {
        this.originalWords2Guess = new ArrayList<>(words2Guess); // Store the original list
        this.words2Guess = new ArrayList<>(words2Guess);
        this.hints = hints;
        for (String word : words2Guess) {
            for (char ch : word.toCharArray()) {
                if (!uniqueLetters.contains(ch)) {
                    uniqueLetters.add(ch);
                }
            }
        }
    }

    public void resetPuzzle() {
        isSolved = false;
        guessedWords.clear();
        correctGuessedWords.clear();
        words2Guess = new ArrayList<>(originalWords2Guess);
        score = 0;
        deduction = 0;
        isCheating = false;
    }

    // Setters and getters for the new field

    public void setDeduction(int deduction) {
        this.deduction = deduction;
    }

    public int getDeduction() {
        return deduction;
    }

    // Existing setters and getters...

    public void setWords2Guess(ArrayList<String> words2Guess) {
        this.words2Guess = words2Guess;
    }

    public void setHints(ArrayList<String> hints) {
        this.hints = hints;
    }

    public void setUniqueLetters(ArrayList<Character> uniqueLetters) {
        this.uniqueLetters = uniqueLetters;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setSolved(boolean isSolved) {
        this.isSolved = isSolved;
    }

    public void setGuessedWords(ArrayList<String> guessedWords) {
        this.guessedWords = guessedWords;
    }

    public void setCorrectGuessedWords(ArrayList<String> correctGuessedWords) {
        this.correctGuessedWords = correctGuessedWords;
    }

    public void setIsCheating(boolean isCheating) {
        this.isCheating = isCheating;
    }

    public List<String> getGuessedWords() {
        return guessedWords;
    }

    public int getScore() {
        return score;
    }

    public boolean isSolved() {
        return isSolved;
    }

    public List<String> getCorrectGuessedWords() {
        return correctGuessedWords;
    }

    public List<String> getWords2Guess() {
        return words2Guess;
    }

    public List<String> getHints() {
        return hints;
    }

    public List<Character> getUniqueLetters() {
        return uniqueLetters;
    }

    public boolean getIsCheating() {
        return isCheating;
    }

    public String toString() {
        String result = isSolved ? "You solved the puzzle!\n" : "You have not solved the puzzle yet.\n";
        result += "Your score is " + score + "\n";
        return result;
    }
}
