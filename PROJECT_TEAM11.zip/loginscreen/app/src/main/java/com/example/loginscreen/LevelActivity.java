package com.example.loginscreen;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LevelActivity extends AppCompatActivity {
    private boolean level1Complete = false;
    private boolean level2Complete = false;
    private boolean level3Complete = false;
    private boolean level4Complete = false;
    private boolean level5Complete = false;

    private static final int TOTAL_LEVELS = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.level_activity);

        String name = getIntent().getStringExtra("NAME");

        Button levelButton1 = findViewById(R.id.levelButton1);
        levelButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(1);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level1-20");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000);
            }
        });

        Button levelButton2 = findViewById(R.id.levelButton2);
        levelButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(2);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level-1-316");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000);
            }
        });

        Button levelButton3 = findViewById(R.id.levelButton3);
        levelButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(3);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level-2-311");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000);
            }
        });

        Button levelButton4 = findViewById(R.id.levelButton4);
        levelButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(4);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level-3-271");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000);
            }
        });

        Button levelButton5 = findViewById(R.id.levelButton5);
        levelButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(5);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level-4-195");
                String letters = "N  T  A  P  E  R  I  S";
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000);
            }
        });

        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("NAME", name);
                finish();
            }
        });
    }

    private void startCrosswordGameActivity(String levelContentUrl) {
        Intent intent = new Intent(LevelActivity.this, CrosswordGameActivity.class);
        intent.putExtra("LEVEL_CONTENT_URL", levelContentUrl);
        startActivity(intent);
    }

    private void toggleLevelCompletion(int levelNumber) {
        switch (levelNumber) {
            case 1:
                level1Complete = !level1Complete;
                break;
            case 2:
                level2Complete = !level2Complete;
                break;
            case 3:
                level3Complete = !level3Complete;
                break;
            case 4:
                level4Complete = !level4Complete;
                break;
            case 5:
                level5Complete = !level5Complete;
                break;
        }
    }

    private void updateProgressBar() {
        int completedLevels = 0;
        if (level1Complete) completedLevels++;
        if (level2Complete) completedLevels++;
        if (level3Complete) completedLevels++;
        if (level4Complete) completedLevels++;
        if (level5Complete) completedLevels++;

        int progress = (int) ((completedLevels / (float) TOTAL_LEVELS) * 100);

        ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setProgress(progress);

        TextView levelsCompletedTextView = findViewById(R.id.levelsCompletedTextView);
        levelsCompletedTextView.setText("Levels Completed: " + completedLevels + "/" + TOTAL_LEVELS);
    }

}
