package com.example.loginscreen;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Looper;
import android.os.Handler;

public class CrosswordGameActivity extends AppCompatActivity {

    private TextView timerTextView;

    private Handler handler = new Handler(Looper.getMainLooper());
    private int secondsPassed = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crossword_game);

        // Get the WebView reference from the layout
        WebView webView = findViewById(R.id.webView);

        // Enable JavaScript (if needed)
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Set a WebViewClient to handle redirects and page loading within the WebView
        webView.setWebViewClient(new WebViewClient());

        // Load the content URL for Level 1
        String levelContentUrl = getIntent().getStringExtra("LEVEL_CONTENT_URL");
        webView.loadUrl(levelContentUrl);


        //Displaying letters for Level 1
        if (levelContentUrl.contains("https://crosswordlabs.com/embed/level1-20")) {
            TextView textView = findViewById(R.id.letters);
            textView.setText("S  T  E  L  A");
        }
        //Displaying letter for Level 2
        else if (levelContentUrl.contains("https://crosswordlabs.com/embed/level-1-316")) {
            TextView textView = findViewById(R.id.letters);
            textView.setText("J  E  P  R  C  O  T");
        }
        //Displaying letter for Level 3
        else if (levelContentUrl.contains("https://crosswordlabs.com/embed/level-2-311")) {
            TextView textView = findViewById(R.id.letters);
            textView.setText("R  C  P  T  O  U  E  M");
        }
        //Displaying letter for Level 4
        else if (levelContentUrl.contains("https://crosswordlabs.com/embed/level-3-271")) {
            TextView textView = findViewById(R.id.letters);
            textView.setText("T  E  P  O  L  V  M  N  D");
        }
        //Displaying letters for Level 5
        else if (levelContentUrl.contains("https://crosswordlabs.com/embed/level-4-195")) {
            TextView textView = findViewById(R.id.letters);
            textView.setText("N  T  A  P  E  R  I  S");
        }
    }


    private void updateTimerTextView() {
        timerTextView.setText("Time: " + secondsPassed + "s");
    }
}


