package com.example.loginscreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ScoreActivity extends AppCompatActivity {

    public static final String EXTRA_SCORES = "EXTRA_SCORES";

    private int[] scores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        String name = getIntent().getStringExtra("NAME");
        scores = getIntent().getIntArrayExtra(EXTRA_SCORES);

        TextView nameTextView = findViewById(R.id.nameTextView);
        nameTextView.setText("Name: " + name);

        displayScores();

        displayHighestScore();

        Button shareButton = findViewById(R.id.shareButton);
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int highestScore = findHighestScore();
                shareAchievement(highestScore);
            }
        });


        Button backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("NAME", name);
                resultIntent.putExtra(EXTRA_SCORES, scores);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }

    private void displayScores() {
        TextView[] scoreTextViews = new TextView[]{
                findViewById(R.id.score1TextView),
                findViewById(R.id.score2TextView),
                findViewById(R.id.score3TextView),
                findViewById(R.id.score4TextView),
                findViewById(R.id.score5TextView),
                findViewById(R.id.score6TextView),
                findViewById(R.id.score7TextView),
                findViewById(R.id.score8TextView),
                findViewById(R.id.score9TextView),
                findViewById(R.id.score10TextView)
        };

        for (int i = 0; i < scores.length; i++) {
            scoreTextViews[i].setText("Score " + (i + 1) + ": " + scores[i]);
        }
    }

    private void displayHighestScore() {
        int highestScore = findHighestScore();
        TextView highestScoreTextView = findViewById(R.id.highestScoreTextView);
        highestScoreTextView.setText("Best of 10: " + highestScore);
    }

    private int findHighestScore() {
        int highestScore = scores[0];
        for (int score : scores) {
            if (score > highestScore) {
                highestScore = score;
            }
        }
        return highestScore;
    }

    private void shareAchievement(int score) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, "I just scored " + score + " in Crossword Game!");
        startActivity(Intent.createChooser(shareIntent, "Share your achievement"));
    }
}
