package com.example.loginscreen;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class Mode extends AppCompatActivity {

    private Button buttonClassicMode;

    public static final String EXTRA_NAME = "NAME";

    private Button buttonBlitzMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mode);

        String name = getIntent().getStringExtra(EXTRA_NAME);

        buttonBlitzMode = findViewById(R.id.buttonBlitzMode);
        buttonClassicMode = findViewById(R.id.buttonClassicMode);
        Button backButton = findViewById(R.id.backButton);

        buttonBlitzMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start Blitz Mode Activity
                Intent intent = new Intent(Mode.this, BlitzModeActivity.class);
                intent.putExtra("NAME", name);
                startActivity(intent);
            }
        });

        buttonClassicMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start Blitz Mode Activity
                Intent intent = new Intent(Mode.this, LevelActivity.class);
                intent.putExtra("NAME", name);
                startActivity(intent);
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("NAME", name);
                finish();
            }
        });
    }
}

