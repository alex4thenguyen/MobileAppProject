package com.example.loginscreen;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class BlitzModeActivity extends AppCompatActivity {
    private List<Integer> allScores = new ArrayList<>();

    private int score = 0;

    private ArrayList<Puzzle> puzzles;
    private String name;
    private int currentPuzzleIndex = 0;
    private TextView textViewHints, textViewScore, textViewTimer, textViewTracker, textViewWordsLeft;
    private EditText editTextGuess;
    private Button buttonSubmit, buttonCheat;
    private Timer timer;
    private long timeRemaining = 180000; // 3 minutes in milliseconds
    private Handler uiHandler = new Handler(Looper.getMainLooper());
    private TextView textViewEnding;
    private Button buttonHome, buttonRetry;
    private int bonusPoints;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blitz_mode);
        name = getIntent().getStringExtra("NAME");

        textViewHints = findViewById(R.id.textViewHints);
        textViewScore = findViewById(R.id.textViewScore);
        textViewTimer = findViewById(R.id.textViewTimer);
        textViewTracker = findViewById(R.id.textViewTracker);
        textViewWordsLeft = findViewById(R.id.textViewWordsLeft);
        editTextGuess = findViewById(R.id.editTextGuess);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonCheat = findViewById(R.id.buttonCheat);
        textViewEnding = findViewById(R.id.textViewEnding);
        buttonHome = findViewById(R.id.buttonHome);
        buttonRetry = findViewById(R.id.buttonRetry);

        initializeViews();

        setupButtonListeners();

        // List of words for the puzzle0 or level 1
        ArrayList<String> words2Guess0 = new ArrayList<>(Arrays.asList("lame", "meal", "male", "mela", "leam"));
        // Corresponding hints for each word
        ArrayList<String> hints0 = new ArrayList<>(Arrays.asList(
                "Uninspiring and dull.",
                "The food served and eaten at one time.",
                "Referring to one of the two human sexes.",
                "A fair or Hindu festival in Indian subcontinent.",
                "Chiefly Scottish: a gleam of light."));
        // Create a Puzzle object with the words and hints
        Puzzle puzzle0 = new Puzzle(words2Guess0, hints0);

        // List of words for the puzzle1 or level 2
        ArrayList<String> words2Guess1 = new ArrayList<>(Arrays.asList("slate", "stale", "least", "steal", "tales"));
        ArrayList<String> hints1 = new ArrayList<>(Arrays.asList(
                "A type of rock often used for roofing.",
                "Not fresh anymore.",
                "Minimum or smallest amount.",
                "To take something without permission.",
                "Plural of a story or narrative."));
        Puzzle puzzle1 = new Puzzle(words2Guess1, hints1);

        // List of words for the puzzle2 or level 3
        ArrayList<String> words2Guess2 = new ArrayList<>(Arrays.asList("master", "stream", "tamers", "ramets", "maters"));
        ArrayList<String> hints2 = new ArrayList<>(Arrays.asList(
                "A person with outstanding skill in a particular activity or as a leader.",
                "A small, narrow river.",
                "Plural form of someone who domesticates or controls wild animals.",
                "Plural form for any of the individuals in a group of clones in botanical term.",
                "Informal, somewhat archaic term for mothers."));
        Puzzle puzzle2 = new Puzzle(words2Guess2, hints2);

        // List of words for the puzzle3 or level 4
        ArrayList<String> words2Guess3 = new ArrayList<>(Arrays.asList("parties", "pirates", "pastier", "traipse", "piaster"));
        ArrayList<String> hints3 = new ArrayList<>(Arrays.asList(
                "Social gatherings or celebrations with music, food, and entertainment.",
                "Outlaws who rob or commit illegal violence at sea.",
                "Comparative adjective for something that resembles paste in texture.",
                "To walk or move wearily or reluctantly, often aimlessly.",
                "A unit of currency in various countries, especially in the Middle East and North Africa." ));
        Puzzle puzzle3 = new Puzzle(words2Guess3, hints3);

        // List of words for the puzzle4 or level 5
        ArrayList<String> words2Guess4 = new ArrayList<>(Arrays.asList(
                "painters", "pantries", "pertains", "pinaster", "pristane"));
        ArrayList<String> hints4 = new ArrayList<>(Arrays.asList(
                "Professionals who apply color to surfaces, such as walls and canvases.",
                "Storage areas in a home for food, dishes, and provisions.",
                "To be relevant or applicable to a particular matter or subject.",
                "A type of pine tree, often found in Mediterranean regions.",
                "A type of saturated terpenoid hydrocarbon, commonly used in scientific research." ));
        Puzzle puzzle4 = new Puzzle(words2Guess4, hints4);
        puzzles = new ArrayList<>(Arrays.asList(puzzle0, puzzle1, puzzle2, puzzle3, puzzle4)); // Populate this list with your Puzzle objects

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playBlitz();
            }
        });

        buttonCheat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Puzzle currentPuzzle = puzzles.get(currentPuzzleIndex);
                currentPuzzle.setIsCheating(true);

                score -= 1000;
                updateTracker();
                updateUI();
            }
        });

        textViewWordsLeft.setVisibility(View.INVISIBLE); // Initially invisible

        startTimer();
        updateUI();
    }

    private void initializeViews() {
        // Buttons
        buttonHome = findViewById(R.id.buttonHome);
        buttonRetry = findViewById(R.id.buttonRetry);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonCheat = findViewById(R.id.buttonCheat);

        // TextViews
        textViewHints = findViewById(R.id.textViewHints);
        textViewScore = findViewById(R.id.textViewScore);
        textViewTimer = findViewById(R.id.textViewTimer);
        textViewTracker = findViewById(R.id.textViewTracker);
        textViewWordsLeft = findViewById(R.id.textViewWordsLeft);
        textViewEnding = findViewById(R.id.textViewEnding);
        editTextGuess = findViewById(R.id.editTextGuess);
        textViewWordsLeft.setVisibility(View.INVISIBLE);
        textViewEnding.setVisibility(View.INVISIBLE);
    }

    private void resetPuzzles() {
        for (Puzzle puzzle : puzzles) {
            puzzle.resetPuzzle();
        }
    }

    private void endGame(boolean allPuzzlesSolved) {
        int totalScore = calculateTotalScore();
        int bonus = allPuzzlesSolved ? calculateBonusPoints() : 0; // Add bonus only if all puzzles are solved

        String message = allPuzzlesSolved ? "Congratulations! You solved all puzzles.\n" : "Time's up! Try better next time.\n";
        message += "Total Score: " + (score + bonusPoints) + "\n";

        if (allPuzzlesSolved) {
            long timeLeft = timeRemaining / 1000; // Convert milliseconds to seconds
            message += "Time Left: " + timeLeft + " seconds\n";
        }

        textViewEnding.setText(message);
        textViewEnding.setVisibility(View.VISIBLE);
        toggleGameViewsVisibility(false); // Hide other game views
    }


    private void toggleGameViewsVisibility(boolean visible) {
        int visibility = visible ? View.VISIBLE : View.INVISIBLE;

        textViewHints.setVisibility(visibility);
        textViewScore.setVisibility(visibility);
        textViewTimer.setVisibility(visibility);
        textViewTracker.setVisibility(visibility);
        textViewWordsLeft.setVisibility(visibility);
        editTextGuess.setVisibility(visibility);
        buttonSubmit.setVisibility(visibility);
        buttonCheat.setVisibility(visibility);
    }

    private void setupButtonListeners() {
        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int[] scores = retrievelist10ScoresHistory(name);
                scores = shiftScoresDown(scores);
                scores[0] = score + bonusPoints;
                saveList10ScoresHistory(name, scores);

                allScores.add(score + bonusPoints);
                saveScoresHistory(name, allScores);

                int highestScore = getHighestScore(name);
                if (score + bonusPoints > highestScore) {
                    saveHighestScore(name, score + bonusPoints);
                }

                Intent intent = new Intent(BlitzModeActivity.this, GameScreen.class);
                intent.putExtra(GameScreen.EXTRA_NAME, name);
                startActivity(intent);
            }
        });

        buttonRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startGame();
            }
        });
    }
    private int calculateTotalScore() {
        int totalScore = 0;
        for (Puzzle puzzle : puzzles) {
            totalScore += puzzle.getScore();
        }
        return totalScore;
    }



    private void startGame() {
        // Call the method to reset the game
        resetGame();

        // Start the game
        startTimer();
        updateUI();
    }

    private void resetGame() {
        currentPuzzleIndex = 0;
        timeRemaining = 180000;
        score = 0;
        resetPuzzles();

        textViewEnding.setVisibility(View.INVISIBLE);
        toggleGameViewsVisibility(true);
    }


    private int calculateBonusPoints() {
        bonusPoints = (int) (timeRemaining / 1000) * 100;
        return bonusPoints;
    }

    private void playBlitz() {
        String guess = editTextGuess.getText().toString();
        editTextGuess.setText("");

        Puzzle currentPuzzle = puzzles.get(currentPuzzleIndex);

        boolean isCorrect = guess(guess, currentPuzzle);
        updateUI();

        if (isCorrect && isPuzzleSolved(currentPuzzle)) {
            currentPuzzle.setSolved(true);
            currentPuzzleIndex++;
            if (currentPuzzleIndex < puzzles.size()) {
                updateUI();
            } else {
                boolean allPuzzlesSolved = areAllPuzzlesSolved();
                endGame(allPuzzlesSolved);
            }
        }
    }


    public boolean guess(String word, Puzzle currentPuzzle) {
        currentPuzzle.getGuessedWords().add(word);
        if (currentPuzzle.getWords2Guess().contains(word)) {
            currentPuzzle.getWords2Guess().remove(word);
            currentPuzzle.getCorrectGuessedWords().add(word);
            score += word.length() * 100;
            if (currentPuzzle.getWords2Guess().isEmpty()) {
                currentPuzzle.setSolved(true);
            }
            return true;
        } else {
            score -= 200;
            currentPuzzle.setScore(currentPuzzle.getScore() - currentPuzzle.getDeduction());
            return false;
        }
    }

    private boolean isPuzzleSolved(Puzzle puzzle) {
        return puzzle.getWords2Guess().isEmpty();
    }


    private void startTimer() {
        if (timer != null) {
            timer.cancel();
            timer.purge();
        }

        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                timeRemaining -= 1000;
                uiHandler.post(() -> updateTimerUI());
                if (timeRemaining <= 0) {
                    timer.cancel();
                    uiHandler.post(() -> {
                        boolean allPuzzlesSolved = areAllPuzzlesSolved();
                        endGame(allPuzzlesSolved);
                    });
                }
            }
        }, 0, 1000);
    }

    private boolean areAllPuzzlesSolved() {
        for (Puzzle puzzle : puzzles) {
            if (!puzzle.isSolved()) {
                return false;
            }
        }
        return true;
    }

    private void updateTimerUI() {
        long minutes = (timeRemaining / 1000) / 60;
        long seconds = (timeRemaining / 1000) % 60;
        textViewTimer.setText(String.format("%02d:%02d", minutes, seconds));
    }

    private void updateUI() {
        Puzzle currentPuzzle = puzzles.get(currentPuzzleIndex);
        String guide = "\n" + currentPuzzle.getHints().get(0)
                + "\n" + currentPuzzle.getHints().get(1)
                + "\n" + currentPuzzle.getHints().get(2)
                + "\n" + currentPuzzle.getHints().get(3)
                + "\n" + currentPuzzle.getHints().get(4);
        textViewHints.setText("Hints: " + guide);
        textViewScore.setText("Score: " + score);
        updateTracker();
        textViewWordsLeft.setVisibility(currentPuzzle.getIsCheating() ? View.VISIBLE : View.INVISIBLE);
    }

    private void updateTracker() {
        Puzzle currentPuzzle = puzzles.get(currentPuzzleIndex);
        ArrayList<Character> shuffledLetters = new ArrayList<>(currentPuzzle.getUniqueLetters());
        Collections.shuffle(shuffledLetters);

        String trackerInfo = "Guessed Words: " + currentPuzzle.getGuessedWords() + "\n" +
                "Correct Words: " + currentPuzzle.getCorrectGuessedWords() + "\n" +
                "Unique Letters: " + shuffledLetters;
        textViewTracker.setText(trackerInfo);

        if (currentPuzzle.getIsCheating()) {
            textViewWordsLeft.setText("Words Left: " + currentPuzzle.getWords2Guess());
            textViewWordsLeft.setVisibility(View.VISIBLE);
        } else {
            textViewWordsLeft.setVisibility(View.INVISIBLE);
        }
    }

    private void saveList10ScoresHistory(String name, int[] scores) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        for (int i = 0; i < scores.length; i++) {
            editor.putInt(name + "_score_" + (i + 1), scores[i]);
        }
        editor.apply();
    }

    private int[] retrievelist10ScoresHistory(String name) {
        int[] scores = new int[10];
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        for (int i = 0; i < scores.length; i++) {
            scores[i] = sharedPreferences.getInt(name + "_score_" + (i + 1), 0);
        }
        return scores;
    }


    private void saveScoresHistory(String name, List<Integer> scores) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        int highestScore = getHighestScore(name);

        for (int i = 0; i < scores.size(); i++) {
            int currentScore = scores.get(i);
            editor.putInt(name + "_score_" + (i + 1), currentScore);

            if (currentScore > highestScore) {
                highestScore = currentScore;
            }
        }

        editor.putInt(name + "_highest_score", highestScore);

        editor.apply();
    }

    private int getHighestScore(String name) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        return sharedPreferences.getInt(name + "_highest_score", 0);
    }

    private void saveHighestScore(String name, int score) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(name + "_highest_score", score);
        editor.apply();
    }

    private int[] shiftScoresDown(int[] scores) {
        for (int i = scores.length - 1; i > 0; i--) {
            scores[i] = scores[i - 1];
        }
        return scores;
    }
}
