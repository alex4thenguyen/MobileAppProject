package com.example.loginscreen;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ForgetPasswordActivity extends AppCompatActivity {

    private EditText editTextUsernameForget, editTextNameForget, editTextPhoneNumberForget;
    private Button buttonNextForget, buttonBackForget;

    private static final String PREFS_NAME = "MyPrefsFile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        editTextUsernameForget = findViewById(R.id.editTextUsernameForget);
        editTextNameForget = findViewById(R.id.editTextNameForget);
        editTextPhoneNumberForget = findViewById(R.id.editTextPhoneNumberForget);
        buttonNextForget = findViewById(R.id.buttonNextForget);
        buttonBackForget = findViewById(R.id.buttonBackForget);

        buttonNextForget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = editTextUsernameForget.getText().toString();
                String name = editTextNameForget.getText().toString();
                String phoneNumber = editTextPhoneNumberForget.getText().toString();

                if (TextUtils.isEmpty(username) || TextUtils.isEmpty(name) || TextUtils.isEmpty(phoneNumber)) {
                    Toast.makeText(ForgetPasswordActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else if (isValidInformation(username, name, phoneNumber)) {
                    Intent intent = new Intent(ForgetPasswordActivity.this, ResetPasswordActivity.class);

                    intent.putExtra("username", username);
                    intent.putExtra("name", name);
                    intent.putExtra("phoneNumber", phoneNumber);

                    startActivity(intent);
                } else {
                    Toast.makeText(ForgetPasswordActivity.this, "Incorrect information. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonBackForget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ForgetPasswordActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean isValidInformation(String username, String name, String phoneNumber) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String savedNameKey = "name_" + username;
        String savedPhoneNumberKey = "phoneNumber_" + username;

        String trimmedName = name.trim();

        return trimmedName.equals(prefs.getString(savedNameKey, ""))
                && phoneNumber.equals(prefs.getString(savedPhoneNumberKey, ""));
    }
}
