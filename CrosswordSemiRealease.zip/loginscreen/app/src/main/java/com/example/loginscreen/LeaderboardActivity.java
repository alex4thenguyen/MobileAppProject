package com.example.loginscreen;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class LeaderboardActivity extends AppCompatActivity {

    private String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        name = getIntent().getStringExtra("NAME");

        int highestScore = getHighestScore(name);

        TextView highestScoreTextView = findViewById(R.id.highestScoreTextView);
        if (highestScoreTextView != null) {
            highestScoreTextView.setText("Highest Score for " + name + ": " + highestScore);

            displayAllNamesWithHighestScores();
        }

        Button backButton = findViewById(R.id.backButton);
        if (backButton != null) {
            backButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(LeaderboardActivity.this, GameScreen.class);
                    intent.putExtra(GameScreen.EXTRA_NAME, name);
                    startActivity(intent);
                    finish();
                }
            });
        }
    }

    private void displayAllNamesWithHighestScores() {
        Map<String, Integer> allNamesWithScores = getAllNamesWithHighestScores();

        if (allNamesWithScores != null) {
            List<Map.Entry<String, Integer>> entryList = new ArrayList<>(allNamesWithScores.entrySet());

            Collections.sort(entryList, (entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));

            int userIndex = -1;
            for (int i = 0; i < entryList.size(); i++) {
                if (entryList.get(i).getKey().equals(name)) {
                    userIndex = i;
                    break;
                }
            }



            int topCount = Math.min(entryList.size(), 5);
            List<Map.Entry<String, Integer>> topEntries = entryList.subList(0, topCount);

            TextView allNamesTextView = findViewById(R.id.allNamesTextView);

            if (allNamesTextView != null) {
                StringBuilder displayText = new StringBuilder();
                int rank = 1;
                for (Map.Entry<String, Integer> entry : topEntries) {
                    displayText.append(rank).append(". ").append(entry.getKey()).append(": ").append(entry.getValue()).append("\n\n");
                    rank++;
                }

                allNamesTextView.setText(displayText.toString());
            }
        }
    }

    private Map<String, Integer> getAllNamesWithHighestScores() {
        Map<String, Integer> namesWithScores = new HashMap<>();

        List<String> allNames = getAllSavedNames();

        for (String name : allNames) {
            int highestScore = getHighestScore(name);
            namesWithScores.put(name, highestScore);
        }

        return namesWithScores;
    }

    private List<String> getAllSavedNames() {
        List<String> allNames = new ArrayList<>();
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", MODE_PRIVATE);

        Map<String, ?> allEntries = sharedPreferences.getAll();
        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            if (entry.getKey() != null && entry.getKey().endsWith("_highest_score")) {
                String name = entry.getKey().replace("_highest_score", "");
                allNames.add(name);
            }
        }

        return allNames;
    }

    private int getHighestScore(String name) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", MODE_PRIVATE);
        return sharedPreferences.getInt(name + "_highest_score", 0);
    }
}
