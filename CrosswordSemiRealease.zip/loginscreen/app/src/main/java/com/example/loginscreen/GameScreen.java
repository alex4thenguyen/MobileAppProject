package com.example.loginscreen;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.app.Dialog;

import androidx.appcompat.app.AppCompatActivity;

import java.util.logging.Level;

public class GameScreen extends AppCompatActivity {

    public static final String EXTRA_NAME = "NAME";
    private static final int SCORE_ACTIVITY_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);

        String name = getIntent().getStringExtra(EXTRA_NAME);

        TextView welcomeTextView = findViewById(R.id.welcomeTextView);

        if (name != null && !name.trim().isEmpty()) {
            welcomeTextView.setText("Welcome, " + name + "!");
        }

        Button startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GameScreen.this, TimerActivity.class);
                intent.putExtra("NAME", name);
                startActivity(intent);
            }
        });

        Button scoreButton = findViewById(R.id.scoresButton);
        scoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String playerName = getIntent().getStringExtra(EXTRA_NAME);
                int[] scores = retrieveAllScores(playerName);

                Intent scoreActivityIntent = new Intent(GameScreen.this, ScoreActivity.class);

                scoreActivityIntent.putExtra(EXTRA_NAME, playerName);
                scoreActivityIntent.putExtra(ScoreActivity.EXTRA_SCORES, scores);

                startActivityForResult(scoreActivityIntent, SCORE_ACTIVITY_REQUEST_CODE);
            }
        });

        Button leaderboardButton = findViewById(R.id.leaderboardButton);
        leaderboardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GameScreen.this, LeaderboardActivity.class);
                intent.putExtra(EXTRA_NAME, name);
                startActivity(intent);
            }
        });

        TextView textViewLogout = findViewById(R.id.textViewLogout);
        textViewLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showLogoutDialog();
            }
        });
    }

    private void showLogoutDialog() {
        final Dialog dialog = new Dialog(GameScreen.this, android.R.style.Theme_DeviceDefault_Light_Dialog_NoActionBar);
        dialog.setContentView(R.layout.popup_logout);

        TextView textViewMessage = dialog.findViewById(R.id.textViewMessage);
        Button buttonYes = dialog.findViewById(R.id.buttonYes);
        Button buttonNo = dialog.findViewById(R.id.buttonNo);

        textViewMessage.setText("Are you sure you want to logout?");

        buttonYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GameScreen.this, MainActivity.class);
                startActivity(intent);
                finish();
                dialog.dismiss();
            }
        });

        buttonNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.show();

        dialog.setCanceledOnTouchOutside(false);
    }



    private int[] retrieveAllScores(String name) {
        int[] allScores = new int[10];
        SharedPreferences sharedPreferences = getSharedPreferences("user_scores", Context.MODE_PRIVATE);
        for (int i = 0; i < allScores.length; i++) {
            allScores[i] = sharedPreferences.getInt(name + "_score_" + (i + 1), 0);
        }
        return allScores;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SCORE_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
        }
    }
}
