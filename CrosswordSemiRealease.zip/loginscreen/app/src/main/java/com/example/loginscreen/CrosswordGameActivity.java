package com.example.loginscreen;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class CrosswordGameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crossword_game);

        // Get the WebView reference from the layout
        WebView webView = findViewById(R.id.webView);

        // Enable JavaScript (if needed)
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Set a WebViewClient to handle redirects and page loading within the WebView
        webView.setWebViewClient(new WebViewClient());

        // Load the content URL for Level 1
        String levelContentUrl = getIntent().getStringExtra("LEVEL_CONTENT_URL");
        webView.loadUrl(levelContentUrl);
    }
}
