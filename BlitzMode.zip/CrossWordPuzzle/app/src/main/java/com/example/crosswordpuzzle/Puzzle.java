package com.example.crosswordpuzzle;

import java.util.*;
public class Puzzle {
    private List<String> words2Guess;
    private List<String>  originalWords2Guess; // Stores the original list of words
    private List<String> guessedWords = new ArrayList<>();
    private List<String> correctGuessedWords = new ArrayList<>();
    private List<Character> uniqueLetters = new ArrayList<>();
    private List<String> hints;
    private boolean isSolved = false;
    private int score = 0;
    private int deduction = 0;
    private boolean isCheating = false;

    public Puzzle(ArrayList<String> words2Guess, ArrayList<String> hints) {
        this.originalWords2Guess = new ArrayList<>(words2Guess); // Store original list
        this.words2Guess = new ArrayList<>(words2Guess);
        this.hints = hints;
        //Userstory 2
        for (String word : words2Guess) {
            for (char ch : word.toCharArray()) {
                if (!uniqueLetters.contains(ch)) {
                    uniqueLetters.add(ch);
                }
            }
        }
    }

    public boolean guess(String word) {
        guessedWords.add(word);
        if (words2Guess.contains(word)) {
            words2Guess.remove(word);
            correctGuessedWords.add(word);
            score += word.length() * 10; // Example scoring logic
            if (words2Guess.isEmpty()) {
                isSolved = true;
            }
            return true;
        } else {
            deduction += 5;
            score = score - deduction;
            return false;
        }
    }

    public void resetPuzzle() {
        isSolved = false;
        guessedWords.clear();
        correctGuessedWords.clear(); // Clear the list of correctly guessed words
        words2Guess = new ArrayList<>(originalWords2Guess); // Reset to original list
        score = 0;
        deduction = 0;
        isCheating = false;
    }

    //Setters
    public void setWords2Guess(ArrayList<String> words2Guess) {
        this.words2Guess = words2Guess;
    }

    public void setHints(ArrayList<String> hints) {
        this.hints = hints;
    }

    public void setUniqueLetters(ArrayList<Character> uniqueLetters) {
        this.uniqueLetters = uniqueLetters;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setSolved(boolean isSolved) {
        this.isSolved = isSolved;
    }

    public void setGuessedWords(ArrayList<String> guessedWords) {
        this.guessedWords = guessedWords;
    }

    public void setCorrectGuessedWords(ArrayList<String> correctGuessedWords) {
        this.correctGuessedWords = correctGuessedWords;
    }

    public void setIsCheating(boolean isCheating) {
        this.isCheating = isCheating;
    }

    //Getters
    public List<String> getGuessedWords() {
        return guessedWords;
    }

    public int getScore() {
        return score;
    }

    public boolean isSolved() {
        return isSolved;
    }

    public List<String> getCorrectGuessedWords() {
        return correctGuessedWords;
    }


    public List<String> getWords2Guess() {
        return words2Guess;
    }

    public List<String> getHints() {
        return hints;
    }

    public List<Character> getUniqueLetters() {
        return uniqueLetters;
    }

    public boolean getIsCheating() {
        return isCheating;
    }

    //Shows score and if puzzle is solved
    public String toString() {
        String result = isSolved ? "You solved the puzzle!\n" : "You have not solved the puzzle yet.\n";
        result += "Your score is " + score + "\n";
        return result;
    }
}
