package com.example.crosswordpuzzle;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class BlitzModeActivity extends AppCompatActivity {
    private ArrayList<Puzzle> puzzles;
    private int currentPuzzleIndex = 0;
    private TextView textViewHints, textViewScore, textViewTimer, textViewTracker, textViewWordsLeft;
    private EditText editTextGuess;
    private Button buttonSubmit, buttonCheat;
    private Timer timer;
    private long timeRemaining = 180000; // 3 minutes in milliseconds
    private Handler uiHandler = new Handler(Looper.getMainLooper());
    private TextView textViewEnding;
    private Button buttonHome, buttonRetry;
    private int bonusPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blitz_mode);

        textViewHints = findViewById(R.id.textViewHints);
        textViewScore = findViewById(R.id.textViewScore);
        textViewTimer = findViewById(R.id.textViewTimer);
        textViewTracker = findViewById(R.id.textViewTracker);
        textViewWordsLeft = findViewById(R.id.textViewWordsLeft);
        editTextGuess = findViewById(R.id.editTextGuess);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonCheat = findViewById(R.id.buttonCheat);
        textViewEnding = findViewById(R.id.textViewEnding);
        buttonHome = findViewById(R.id.buttonHome);
        buttonRetry = findViewById(R.id.buttonRetry);

        // Initialize all views
        initializeViews();

        // Setup listeners for new buttons
        setupButtonListeners();

        // List of words for the puzzle0 or level 1
        ArrayList<String> words2Guess0 = new ArrayList<>(Arrays.asList("lame", "meal", "male", "mela", "leam"));
        // Corresponding hints for each word
        ArrayList<String> hints0 = new ArrayList<>(Arrays.asList(
                "Uninspiring and dull.",
                "The food served and eaten at one time.",
                "Referring to one of the two human sexes.",
                "A fair or Hindu festival in Indian subcontinent.",
                "Chiefly Scottish: a gleam of light."));
        // Create a Puzzle object with the words and hints
        Puzzle puzzle0 = new Puzzle(words2Guess0, hints0);

        // List of words for the puzzle1 or level 2
        ArrayList<String> words2Guess1 = new ArrayList<>(Arrays.asList("slate", "stale", "least", "steal", "tales"));
        ArrayList<String> hints1 = new ArrayList<>(Arrays.asList(
                "A type of rock often used for roofing.",
                "Not fresh anymore.",
                "Minimum or smallest amount.",
                "To take something without permission.",
                "Plural of a story or narrative."));
        Puzzle puzzle1 = new Puzzle(words2Guess1, hints1);

        // List of words for the puzzle2 or level 3
        ArrayList<String> words2Guess2 = new ArrayList<>(Arrays.asList("master", "stream", "tamers", "ramets", "maters"));
        ArrayList<String> hints2 = new ArrayList<>(Arrays.asList(
                "A person with outstanding skill in a particular activity or as a leader.",
                "A small, narrow river.",
                "Plural form of someone who domesticates or controls wild animals.",
                "Plural form for any of the individuals in a group of clones in botanical term.",
                "Informal, somewhat archaic term for mothers."));
        Puzzle puzzle2 = new Puzzle(words2Guess2, hints2);

        // List of words for the puzzle3 or level 4
        ArrayList<String> words2Guess3 = new ArrayList<>(Arrays.asList("parties", "pirates", "pastier", "traipse", "piaster"));
        ArrayList<String> hints3 = new ArrayList<>(Arrays.asList(
                "Social gatherings or celebrations with music, food, and entertainment.",
                "Outlaws who rob or commit illegal violence at sea.",
                "Comparative adjective for something that resembles paste in texture.",
                "To walk or move wearily or reluctantly, often aimlessly.",
                "A unit of currency in various countries, especially in the Middle East and North Africa." ));
        Puzzle puzzle3 = new Puzzle(words2Guess3, hints3);

        // List of words for the puzzle4 or level 5
        ArrayList<String> words2Guess4 = new ArrayList<>(Arrays.asList(
                "painters", "pantries", "pertains", "pinaster", "pristane"));
        ArrayList<String> hints4 = new ArrayList<>(Arrays.asList(
                "Professionals who apply color to surfaces, such as walls and canvases.",
                "Storage areas in a home for food, dishes, and provisions.",
                "To be relevant or applicable to a particular matter or subject.",
                "A type of pine tree, often found in Mediterranean regions.",
                "A type of saturated terpenoid hydrocarbon, commonly used in scientific research." ));
        Puzzle puzzle4 = new Puzzle(words2Guess4, hints4);
        // Initialize puzzles
        puzzles = new ArrayList<>(Arrays.asList(puzzle0, puzzle1, puzzle2, puzzle3, puzzle4)); // Populate this list with your Puzzle objects

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                playBlitz();
            }
        });

        buttonCheat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Puzzle currentPuzzle = puzzles.get(currentPuzzleIndex);
                currentPuzzle.setIsCheating(true);
                updateTracker();
            }
        });

        textViewWordsLeft.setVisibility(View.INVISIBLE); // Initially invisible

        startTimer();
        updateUI();
    }

    private void initializeViews() {
        // Buttons
        buttonHome = findViewById(R.id.buttonHome);
        buttonRetry = findViewById(R.id.buttonRetry);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonCheat = findViewById(R.id.buttonCheat);

        // TextViews
        textViewHints = findViewById(R.id.textViewHints);
        textViewScore = findViewById(R.id.textViewScore);
        textViewTimer = findViewById(R.id.textViewTimer);
        textViewTracker = findViewById(R.id.textViewTracker);
        textViewWordsLeft = findViewById(R.id.textViewWordsLeft);
        textViewEnding = findViewById(R.id.textViewEnding);

        // EditText
        editTextGuess = findViewById(R.id.editTextGuess);

        // Set initial visibility for certain views
        textViewWordsLeft.setVisibility(View.INVISIBLE);
        textViewEnding.setVisibility(View.INVISIBLE);
    }

    private void setupButtonListeners() {
        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BlitzModeActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        buttonRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startGame();
            }
        });
    }

    private void resetPuzzles() {
        for (Puzzle puzzle : puzzles) {
            puzzle.resetPuzzle();
        }
        // Reset other game state as needed
    }

    private void endGame(boolean allPuzzlesSolved) {
        int totalScore = calculateTotalScore();
        int bonus = allPuzzlesSolved ? calculateBonusPoints() : 0; // Add bonus only if all puzzles are solved

        String message = allPuzzlesSolved ? "Congratulations! You solved all puzzles.\n" : "Time's up! Try better next time.\n";
        message += "Total Score: " + (totalScore + bonus) + "\n";

        if (allPuzzlesSolved) {
            long timeLeft = timeRemaining / 1000; // Convert milliseconds to seconds
            message += "Time Left: " + timeLeft + " seconds\n";
        }

        textViewEnding.setText(message);
        textViewEnding.setVisibility(View.VISIBLE);
        toggleGameViewsVisibility(false); // Hide other game views
    }

    private void toggleGameViewsVisibility(boolean visible) {
        int visibility = visible ? View.VISIBLE : View.INVISIBLE;

        // Set visibility for all game views
        textViewHints.setVisibility(visibility);
        textViewScore.setVisibility(visibility);
        textViewTimer.setVisibility(visibility);
        textViewTracker.setVisibility(visibility);
        textViewWordsLeft.setVisibility(visibility);
        editTextGuess.setVisibility(visibility);
        buttonSubmit.setVisibility(visibility);
        buttonCheat.setVisibility(visibility);
    }

    private int calculateTotalScore() {
        int totalScore = 0;
        for (Puzzle puzzle : puzzles) {
            totalScore += puzzle.getScore();
        }
        return totalScore;
    }

    private void startGame() {
        // Call the method to reset the game
        resetGame();

        // Start the game
        startTimer();
        updateUI();
    }

    private void resetGame() {
        // Reset the current puzzle index and timer
        currentPuzzleIndex = 0;
        timeRemaining = 180000; // Reset the timer to 3 minutes

        // Reset each puzzle
        resetPuzzles();

        // Reset UI elements
        textViewEnding.setVisibility(View.INVISIBLE);
        toggleGameViewsVisibility(true); // Make game-related views visible
    }


    private int calculateBonusPoints() {
        // Assuming 1 bonus point for each second remaining
        bonusPoints = (int) (timeRemaining / 1000) * 10;
        return bonusPoints;
    }

    private void playBlitz() {
        Puzzle currentPuzzle = puzzles.get(currentPuzzleIndex);
        String guess = editTextGuess.getText().toString();
        editTextGuess.setText("");
        boolean isCorrect = currentPuzzle.guess(guess);
        updateUI();

        if (isCorrect && currentPuzzle.isSolved()) {
            currentPuzzleIndex++;
            if (currentPuzzleIndex < puzzles.size()) {
                updateUI();
            } else {
                endGame(true); // All puzzles solved
            }
        }
    }

    private void startTimer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                timeRemaining -= 1000;
                uiHandler.post(() -> updateTimerUI());
                if (timeRemaining <= 0) {
                    timer.cancel();
                    uiHandler.post(() -> endGame(false)); // All puzzles not solved, time's up
                }
            }
        }, 0, 1000);
    }

    private void updateTimerUI() {
        long minutes = (timeRemaining / 1000) / 60;
        long seconds = (timeRemaining / 1000) % 60;
        textViewTimer.setText(String.format("%02d:%02d", minutes, seconds));
    }

    private void updateUI() {
        Puzzle currentPuzzle = puzzles.get(currentPuzzleIndex);
        String guide = "\n" + currentPuzzle.getHints().get(0)
            + "\n" + currentPuzzle.getHints().get(1)
            + "\n" + currentPuzzle.getHints().get(2)
            + "\n" + currentPuzzle.getHints().get(3)
            + "\n" + currentPuzzle.getHints().get(4);
        textViewHints.setText("Hints: " + guide);
        textViewScore.setText("Score: " + currentPuzzle.getScore());
        updateTracker();
        textViewWordsLeft.setVisibility(currentPuzzle.getIsCheating() ? View.VISIBLE : View.INVISIBLE);
    }

    private void updateTracker() {
        Puzzle currentPuzzle = puzzles.get(currentPuzzleIndex);
        ArrayList<Character> shuffledLetters = new ArrayList<>(currentPuzzle.getUniqueLetters());
        Collections.shuffle(shuffledLetters);

        String trackerInfo = "Guessed Words: " + currentPuzzle.getGuessedWords() + "\n" +
                "Correct Words: " + currentPuzzle.getCorrectGuessedWords() + "\n" +
                "Unique Letters: " + shuffledLetters;
        textViewTracker.setText(trackerInfo);

        if (currentPuzzle.getIsCheating()) {
            textViewWordsLeft.setText("Words Left: " + currentPuzzle.getWords2Guess());
            textViewWordsLeft.setVisibility(View.VISIBLE);
        } else {
            textViewWordsLeft.setVisibility(View.INVISIBLE);
        }
    }
}
