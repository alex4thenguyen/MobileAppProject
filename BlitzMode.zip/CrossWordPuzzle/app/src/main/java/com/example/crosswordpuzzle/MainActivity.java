package com.example.crosswordpuzzle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button buttonClassicMode;
    private Button buttonBlitzMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons
        buttonBlitzMode = findViewById(R.id.buttonBlitzMode);

        // Set onClickListeners for the buttons
        buttonBlitzMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Start Blitz Mode Activity
                Intent intent = new Intent(MainActivity.this, BlitzModeActivity.class);
                startActivity(intent);
            }
        });
    }
}
