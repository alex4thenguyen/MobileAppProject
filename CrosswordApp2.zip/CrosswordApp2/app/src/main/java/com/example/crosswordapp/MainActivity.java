package com.example.crosswordapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Flags to track completion status for each level
    private boolean level1Complete = false;
    private boolean level2Complete = false;
    private boolean level3Complete = false;
    private boolean level4Complete = false;
    private boolean level5Complete = false;

    // Total number of levels
    private static final int TOTAL_LEVELS = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set OnClickListener for Level 1 button
        Button levelButton1 = findViewById(R.id.levelButton1);
        levelButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(1);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level1-20");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000); // 1000 milliseconds delay
            }
        });

        // Set OnClickListener for Level 2 button
        Button levelButton2 = findViewById(R.id.levelButton2);
        levelButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(2);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level-1-316");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000); // 1000 milliseconds delay
            }
        });

        // Set OnClickListener for Level 3 button
        Button levelButton3 = findViewById(R.id.levelButton3);
        levelButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(3);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level-2-311");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000); // 1000 milliseconds delay
            }
        });

        // Set OnClickListener for Level 4 button
        Button levelButton4 = findViewById(R.id.levelButton4);
        levelButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(4);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level-3-271");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000); // 1000 milliseconds delay
            }
        });

        // Set OnClickListener for Level 5 button
        Button levelButton5 = findViewById(R.id.levelButton5);
        levelButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleLevelCompletion(5);
                startCrosswordGameActivity("https://crosswordlabs.com/embed/level-4-195");
                String letters = "N  T  A  P  E  R  I  S";
//                TextView textView = findViewById(R.id.letters);
//                textView.setText("N  T  A  P  E  R  I  S");
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        updateProgressBar();
                    }
                }, 1000); // 1000 milliseconds delay
            }
        });
    }

    private void startCrosswordGameActivity(String levelContentUrl) {
        Intent intent = new Intent(MainActivity.this, CrosswordGameActivity.class);
        intent.putExtra("LEVEL_CONTENT_URL", levelContentUrl);
        startActivity(intent);
    }

    private void toggleLevelCompletion(int levelNumber) {
        switch (levelNumber) {
            case 1:
                level1Complete = !level1Complete;
                break;
            case 2:
                level2Complete = !level2Complete;
                break;
            case 3:
                level3Complete = !level3Complete;
                break;
            case 4:
                level4Complete = !level4Complete;
                break;
            case 5:
                level5Complete = !level5Complete;
                break;
        }
    }

    private void updateProgressBar() {
        // Calculate the completion percentage
        int completedLevels = 0;
        if (level1Complete) completedLevels++;
        if (level2Complete) completedLevels++;
        if (level3Complete) completedLevels++;
        if (level4Complete) completedLevels++;
        if (level5Complete) completedLevels++;

        int progress = (int) ((completedLevels / (float) TOTAL_LEVELS) * 100);

        // Update the progress bar
        ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setProgress(progress);

        // Update the TextView displaying the number of completed levels
        TextView levelsCompletedTextView = findViewById(R.id.levelsCompletedTextView);
        levelsCompletedTextView.setText("Levels Completed: " + completedLevels + "/" + TOTAL_LEVELS);
    }

}
